var Messages = {
    20100: require("./Messages/Server/ServerHelloMessage"),
	20104: require("./Messages/Server/LoginOkMessage"),
    24124: require("./Messages/Server/TeamMessage"),
    24131: require("./Messages/Server/TeamStreamMessage"),
    24589: require("./Messages/Server/TeamInvitationMessage"),
    24130: require("./Messages/Server/TeamGameStartingMessage"),
    25892: require("./Messages/Server/DisconnectedMessage")
}

function createMessageByType(type) {
    if (Messages[type]) {
        return new Messages[type]();
    }
}

module.exports = {
    createMessageByType
}
