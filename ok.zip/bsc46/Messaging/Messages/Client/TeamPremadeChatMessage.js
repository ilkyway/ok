var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode() { 
        this.ByteStream.writeDataReference(40, 26);
        this.ByteStream.writeBoolean(false);
        this.ByteStream.writeVInt(0); //unk
        this.ByteStream.writeVInt(26); //unk
        this.ByteStream.writeVInt(0); //unk
    }
}