var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode() { 
        this.ByteStream.writeDataReference(228, 228)
        this.ByteStream.writeVInt(228); //type?
		this.ByteStream.writeVInt(228); //room id
        this.ByteStream.writeVInt(228); //unk
        this.ByteStream.writeVInt(228); //unk
    }
}