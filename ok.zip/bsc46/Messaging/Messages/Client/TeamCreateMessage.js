var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    encode(){
        this.ByteStream.writeVInt(1); //unk
        this.ByteStream.writeVInt(228); //unk
        this.ByteStream.writeVInt(228); //unk
        this.ByteStream.writeBoolean(false); //unk
        this.ByteStream.writeBoolean(false); //unk
        this.ByteStream.writeInt(0); //high
        this.ByteStream.writeInt(1); //low
        this.ByteStream.writeVInt(1); //unk
        this.ByteStream.writeDataReference(1, 1);
        
    }
}