var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    decode() {}
    process(messaging) {
        messaging.sendMatchmakeRequestMessage();
    }
}

module.exports.getMessageType = () => 24130;