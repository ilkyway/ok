var ByteStream = require("../../../DataStream/ByteStream");

module.exports = class {
    constructor() {
        this.ByteStream = new ByteStream();
    }
    decode() {
        // console.log("Unk int" + this.ByteStream.readInt());
        // console.log("Unk int" + this.ByteStream.readInt());
        // // console.log(this.ByteStream.readInt());
        // // console.log(this.ByteStream.readInt());
        // console.log("Team Creator:" + this.ByteStream.readString());
        // console.log("Unk data " + this.ByteStream.readDataReference());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk data " + this.ByteStream.readDataReference());
        // console.log("Unk string " + this.ByteStream.readString());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
        // console.log("Unk int " + this.ByteStream.readInt());
    }
    process(messaging) {
    }
}

module.exports.getMessageType = () => 24131;