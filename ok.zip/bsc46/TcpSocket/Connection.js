var {
    Queue,
    Messaging
} = require("../Messaging/Messaging");

module.exports = function(client) {
    var queue = new Queue();
    var messaging = new Messaging(client, queue);
	messaging.sendPepperAuthentication();
    const readline = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout,
    });

    client.on("data", data => {
        queue.add(data);
        while (messaging.pendingJob()) {
            messaging.update();
		}
    });
    client.on("close",
        () => {
            var queue = new Queue();
            var messaging = new Messaging(client, queue);
            setTimeout(() => {client.connect(9339, "game.brawlstarsgame.com")}, 2000); // prints 
            setTimeout(() => {Debugger.info("Reconnecting...")}, 1000); // prints 
            setTimeout(() => {messaging.sendPepperAuthentication();}, 1000); // prints 
            // messaging.update();
        });
}
